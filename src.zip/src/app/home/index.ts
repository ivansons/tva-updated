﻿export * from './home.component';
