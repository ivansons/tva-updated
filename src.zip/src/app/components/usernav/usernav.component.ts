import { Component, OnInit } from '@angular/core';
import {HomeComponent} from '../../home/home.component';

@Component({
  moduleId: module.id.toString(),
  // tslint:disable-next-line:component-selector
  selector: 'usernav-component',
  templateUrl: 'usernav.component.html',
})
export class UserNavComponent implements OnInit {
  constructor() {

  }
  ngOnInit() {
  }
}


