import { Component, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'app-slider',
  templateUrl: 'slider.component.html',
})
export class SliderComponent implements OnInit {
  constructor() {

  }
  ngOnInit() {
  }
}
