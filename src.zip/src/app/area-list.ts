export class AreaList {

  id: number;  //expected drupal id of taxonomy
  name: string; //expected drupal term name
}
