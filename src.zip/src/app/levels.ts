export class Level {
  id: number;  // expected drupal id of taxonomy
  name: string; // expected drupal term name
}
