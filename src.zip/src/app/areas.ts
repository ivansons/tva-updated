import { AreaList } from './area-list';

export const AREAS: AreaList[] = [
  { id: 1, name: 'Explorer' },
  { id: 2, name: 'TN River Trek' },
  { id: 3, name: 'Nuclear Experment' },
  { id: 4, name: 'Wind Farm Fly Over' },
  { id: 5, name: 'Solar Power' },


];
