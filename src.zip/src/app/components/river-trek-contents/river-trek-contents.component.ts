import { Component, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'app-river-trek-contents',
  templateUrl: './river-trek-contents.component.html',
  styleUrls: ['./river-trek-contents.component.css']
})
export class RiverTrekContentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
