import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-select-band',
  templateUrl: './select-band.component.html',
  styleUrls: ['./select-band.component.css']
})
export class SelectBandComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
