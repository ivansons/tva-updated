export class TrekData {
  userLevel = '';
  userArea = '';
  userPath: any;

}
export class StageOne {
  userLevel  = '';
}
export class StageTwo {
  userArea = '';
}

export class StageThree {
userPath = '';
}

