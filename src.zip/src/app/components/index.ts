export { SliderComponent } from './slider/slider.component';
export { UserNavComponent } from './usernav/usernav.component';
export { WelcomeComponent } from './welcome/welcome.component';
export { SelectBandComponent } from './select-band/select-band.component';
export { UserDashboard } from './userdashboard/userdashboard.component';
export { AreaComponent } from './area/area.component';
export { StartComponent } from './start/start.component';
export { TrekContentsComponent } from './trek-contents/trek-contents.component';
export { RiverTrekStartComponent } from './river-trek-start/river-trek-start.component';
export { RiverTrekContentsComponent } from './river-trek-contents/river-trek-contents.component';
export { MapComponent } from './map/map.component';
export {LevelComponent} from './level/level.component';
export {WorkComponent}  from './work/work.component';
export {AgeComponent} from './age/age.component';




