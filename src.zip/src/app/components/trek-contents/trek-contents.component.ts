import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trek-contents',
  templateUrl: './trek-contents.component.html',
  styleUrls: ['./trek-contents.component.css']
})
export class TrekContentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
