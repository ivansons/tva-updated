export const STEPS = {
    personal: 'personal',
    ages: 'ages',
    address: 'address',
    result: 'result'
}
;
